# Portfolio Website

This is a simple personal portfolio website made using HTML, CSS, and JavaScript.

## 👤 Author
**Abhinav Giri**  
2nd Year Computer Science Student  
GitHub: [A13HINAVg](https://github.com/A13HINAVg)

## 📁 Features
- Simple and clean design
- Light pastel theme
- Responsive layout
- Easy to customize

## 🚀 How to Use
1. Clone or download this repo.
2. Open `index.html` in your browser.
3. Customize as needed!

---
Made with ❤️ for learning and growth.